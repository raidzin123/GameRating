// Игровой лаунчер
const dictionary = require("../dictionary");
const games = require("../games");
const readline = require("reasline").createInterface({
  input: process.stdin,
  output: process.stdout,
  terminal: false,
  prompt: "",
});

const gamesArray = [
  { id: "1", game: game.knightDragonAndPrincessGame },
  { id: "2", game: game.poleChudesGame },
  { id: "3", game: game.makeWordGame },
  { id: "4", game: game.blackJackGame },
  { id: "5", game: game.trueOrFalseGame },
  { id: "6", game: game.dropCoin },
];

async function startGame(gameId) {
  const selectedGame = gamesArray.find((game) => game.id === gameId);
  if (selectedGame) {
    const result = await selectedGame.game();
    countResult(result);
  } else {
    console.log(dictionary.global.wrongInput);
  }
  afterGame(gameId);
}

function countResult(gameResult) {
  if (gameResult === "draw") {
    console.log(dictionary.global.draw);
  } else {
    console.log(gameResult ? dictionary.global.win : dictionary.global.lose);
  }
  afterGame();
}

function afterGame(gameId) {
  readline.question("введи 1 2 или 3", (answer) => {
    if ("1" == answer) {
      startGame(gameId);
    } else if ("2" == answer) {
      startLauncher();
    } else if ("3" == answer) {
      startLauncher();
    }
  });
}

function startLauncher() {
  readline.question(dictionary.global.chooseGame, (answer) => {
    if ("7" == answer) {
      stopLauncher();
    } else {
      startGame(answer);
    }
  });
}

function stopLauncher() {
  console.log(dictionary.global.goodbye);
  readline.close();
}

module.exports = {
  startLauncher,
};
