const knightDragonAndPrincessGame = require("./knight-dragon-princess");
const poleChudesGame = require("./pole-chudes");
const trueOrFalseGame = require("./true-or-false");
const dropCoin = require("./coin");
const makeWordGame = require("./make-word");
const blackJackGame = require("./black-jack");

module.exports = {
  knightDragonAndPrincessGame,
  poleChudesGame,
  trueOrFalseGame,
  dropCoin,
  makeWordGame,
  blackJackGame
};
