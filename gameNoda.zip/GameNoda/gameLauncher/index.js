require("events").EventEmitter.defaultMaxListeners = 0;
const dictionary = require("./AppModules/dictionary");
// Подключите лаунчер, который создали

const { startLauncher } = require("./launcher");

console.log(dictionary.global.hello);
// Вызовите функцию лаунчера

startLauncher();
