const endpoints = require("./config");
const { getData, getRandomGame } = require("./api-utils");

module.exports = {
  endpoints,
  getData,
  getRandomGame,
};
